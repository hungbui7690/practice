const openingHours = {
  thu: {
    open: 12,
    close: 22,
  },
  fri: {
    open: 11,
    close: 23,
  },
  sat: {
    open: 0, // Open 24 hours
    close: 24,
  },
};

/* 
====================================
  1) 
  - lấy ra tất cả keys trong openingHours
  
*/

/* 
====================================
  2) 
  - sau đó viết câu: We are open on 3 days: thu, fri, sat
*/

/* 
====================================
  3) 
  - lấy ra tất cả values trong openingHours
*/

/* 
====================================
  4) 
  - Lấy ra keys + values
*/

/* 
====================================
  5) 
  - Loop object, lấy ra open, close đồng thời in ra câu: On thu, we open at 12 and close at 22
*/

/* 
====================================
  6) 
  - 
*/
