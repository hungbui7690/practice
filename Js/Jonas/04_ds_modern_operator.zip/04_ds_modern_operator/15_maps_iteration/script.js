/* 
====================================
  1) 
  ["question", "What is the best programming language in the world?"],
  [1, "C"],
  [2, "Java"],
  [3, "Javascript"],
  ["correct", 3],
  [true, "Correct 🎉"],
  [false, "Try again! 👎"]
  - tạo map question chứa câu hỏi ở trên
*/

/* 
====================================
  2) 
  - chạy hàm Object.entries() với openingHours
*/

/* 
====================================
  3) 
  - tạo map với object openingHours
*/
const openingHours = {
  thu: {
    open: 12,
    close: 22,
  },
  fri: {
    open: 11,
    close: 23,
  },
  sat: {
    open: 0, // Open 24 hours
    close: 24,
  },
};

/* 
====================================
  4) 
  - loop các item trong map question >> quiz app
*/

/* 
====================================
  5) 
  - convert map trở lại thanh array 
*/

/* 
====================================
  6) 
  - 3 methods sẽ trả về iterators trong map
*/
