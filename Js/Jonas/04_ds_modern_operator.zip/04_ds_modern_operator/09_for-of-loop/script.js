// for-of looop: we can still use the continue & break keywords

const restaurant = {
  starterMenu: ["Focaccia", "Bruschetta", "Garlic Bread", "Caprese Salad"],
  mainMenu: ["Pizza", "Pasta", "Risotto"],
};

/* 
====================================
  1) 
  - tạo ra array menu chứa 2 thằng menus ở trên
*/

/* 
====================================
  2) 
  - sử dụng for-of để loop lấy ra tất cả items
*/

/* 
====================================
  3) 
  - loop bằng for-of, đồng thời lấy ra index (2 cách)
*/
