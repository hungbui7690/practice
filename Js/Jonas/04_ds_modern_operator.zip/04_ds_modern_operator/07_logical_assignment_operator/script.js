/* 
====================================
  1) 
  - check rest1 và rest2: nếu như không có numGuest thì set là 10, nếu có thì sử dụng numGuest
*/
const restaurant1 = {
  name: "Capri",
  numGuest: 25,
};

const restaurant2 = {
  name: "La Pizza",
  owner: "Giovanni Rossi",
};

/* 
====================================
  2) 
  - làm như trên sử dụng nullish với rest3 và rest4
*/
const restaurant3 = {
  name: "D&D",
  numGuest: 0,
};

const restaurant4 = {
  name: "LLL",
  owner: "De Rossi",
};

/* 
====================================
  3) 
  - sử dụng với property owner trong rest3 và rest4 >> nếu không có thì sử dụng ANONYMOUS
  HINT: check thử với &&, rồi check với 2 thằng còn lại
*/
