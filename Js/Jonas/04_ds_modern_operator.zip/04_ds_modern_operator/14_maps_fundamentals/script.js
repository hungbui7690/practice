/* 
====================================
  1) 
  - Tạo ra map mới có tên là restaurant
  - thêm 3 items vào map (name, location, founded)
*/

/* 
====================================
  2) 
  - thêm array categories vào trong set
  - thêm open/close 

*/

/* 
====================================
  3) 
  - kiểm tra xem nhà hàng đã đóng cửa hay chưa
*/
const time = 21;

/* 
====================================
  4) 
  - kiểm tra xem trong map có property categories hay không
*/

/* 
====================================
  5) 
  - xóa hết tất cả elements trong map
*/

/* 
====================================
  6) 
  - xóa bất kỳ element nào trong map
*/

/* 
====================================
  7) 
  - thử lấy boolean, array làm key
*/
