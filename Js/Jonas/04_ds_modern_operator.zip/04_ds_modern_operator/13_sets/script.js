/* 
====================================
  1) 
  - tạo ra set chứa "Pasta", "Pizza", "Pizza", "Risotto", "Pasta"
*/

/* 
====================================
  2) 
  - lấy ra size của set
*/

/* 
====================================
  3) 
  - thêm "Garlic Bread" vào set
  - xóa "Risotto"
*/

/* 
====================================
  4) 
  - xóa hết các elements trong set
*/

/* 
====================================
  5) 
  - loop set
*/

/* 
====================================
  6) 
  - xóa hết duplication trong array bên dưới và lưu vào array
*/
const staff = ["Waiter", "Chef", "Waiter", "Manager", "Chef", "Waiter"];

/* 
====================================
  7) 
  - get unique letters trong chuỗi "I'm superman!!"
*/
