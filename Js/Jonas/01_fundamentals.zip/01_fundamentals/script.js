/* 
||=============================================||
  1) Write the sentence: My name is Hung, and I'm 32 years old.
*/
const studentName = "Hung";
const birthYear = 1990;
// ---------------------------
console.log();

/* 
||=============================================||
  2) Truthy / Falsy Values
*/
console.log(Boolean({}));

/* 
||=============================================||
  3) Convert to Switch
*/
const day = "sunday";
if (day == "monday") console.log("Plan my project");
else if (day == "tuesday") console.log("Meeting");
else if (day == "saturday") console.log("Break");
else console.log("Not a valid day");
// ---------------------------

/* 
||=============================================||
  4) Convert to Ternary Operator
*/
const age = 23;
if (age >= 18) console.log("🍷🍷");
else console.log(`💧`);
// ---------------------------
